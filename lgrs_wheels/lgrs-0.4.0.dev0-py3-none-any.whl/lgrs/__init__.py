"""Top-level package for `lgrs` library."""

# Copyright © 2026, Ethan I. Schaefer (eschaefer@seti.org)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
# implied. See the License for the specific language governing
# permissions and limitations under the License.

__author__ = "lgrs Developers"
__email__ = "eschaefer@seti.org"
__version__ = "0.4.0-dev"

# * IMPORT BEARTYPE. ──────────────────────────────────────────────────
import beartype.claw

# * BUBBLE-UP MOST USEFUL CLASSES AND FUNCTIONS. ──────────────────────
# Note: Unlike in `pyproj`:
from lgrs.bounds import GeographicBounds, ProjectedBounds
from lgrs.caching import enable_caching
from lgrs.database import query_lunar_crs_info
from lgrs.easy import write_grid

# from lgrs.easy import from_geographic, from_gridded, from_lps_or_ltm

# Note: Analogous to `pyproj`:
from lgrs.srs.srs import CRS, make_lunar_crs

# * ENABLE TYPE-CHECKING AT PACKAGE LEVEL. ───────────────────────────
# Note: Types and execution in `lgrs.js` are not available outside a
# JavaScript (Pyodide) environment, so disable type-checking.
beartype.claw.beartype_this_package(
    conf=beartype.BeartypeConf(
        is_pep484_tower=True, claw_skip_package_names=("lgrs.js",)
    )
)
del beartype
