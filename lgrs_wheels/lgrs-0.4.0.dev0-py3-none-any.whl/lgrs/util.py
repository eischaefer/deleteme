"""Support for JavaScript interface."""

# Copyright © 2026, Ethan I. Schaefer (eschaefer@seti.org)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
# implied. See the License for the specific language governing
# permissions and limitations under the License.

###############################################################################
# region> IMPORT
###############################################################################
# Special.
from __future__ import annotations

# Standard.
import collections as _collections
import functools as _functools
import inspect as _inspect
import itertools as _itertools
import re as _re
import types as _types
import typing as _typing

# endregion
###############################################################################
# region> NUMPY DOC PARSING
###############################################################################
# Note: Avoids adding `numpydoc` as a dependency.
type Content = str | dict[str, tuple[str, str]] | None


class NumpyDoc:
    def __init__(self, func: _collections.abc.Callable) -> None:
        self.func = func

    # * UTILITIES. ────────────────────────────────────────────────────
    def _get_value(
        self,
        key: str | int,
        *,
        parent: str | int | None,
    ) -> _typing.Any:
        if parent is None:
            return self.section_name_to_content[key]
        content_mapping = self.section_name_to_content[parent]
        if content_mapping is None:
            return None
        else:
            return content_mapping[key]

    def _resolve_content(
        self,
        key: str | int,
        *,
        parent: str | None = None,
        inherited: NumpyDoc,
        exclude_set: set[str | int],
        extend_set: set[str | int],
        prepend_set: set[str | int],
    ) -> Content:
        # Collect nominal and inherited content.
        nom_content = self._get_value(key, parent=parent)
        if key in exclude_set:
            return nom_content
        inherited_content = inherited._get_value(key, parent=parent)

        # Determine merge behavior, honoring parent's default.
        merge_type = None  # Initialize.
        merge_type_to_set = {
            "exclude": exclude_set,
            "extend": extend_set,
            "prepend": prepend_set,
        }
        for k in (key, parent):
            if k is None:
                continue
            for cand_merge_type, set_ in merge_type_to_set.items():
                if k in set_:
                    merge_type = cand_merge_type
                    break
            else:
                continue
            break  # Cascade.
        if merge_type is None:
            merge_type = "extend"  # Default.

        # Merge (or abort).
        if merge_type == "exclude":
            return nom_content
        if nom_content is None:
            return inherited_content
        if inherited_content is None:
            return nom_content
        assert isinstance(nom_content, str)
        # TODO: Actually, extending and prepending differ depending on
        #  whether an empty line is needed between or text should be
        #  wrapped.
        match merge_type:
            case "extend":
                return inherited_content + nom_content
            case "prepend":
                return nom_content + inherited_content
            case _:
                raise TypeError(
                    f"`merge_type` is not recognized {merge_type!r}"
                )

    def _resolve_section_content(
        self,
        section_key: str | int,
        *,
        inherited: NumpyDoc,
        exclude_set: set[str | int],
        extend_set: set[str | int],
        prepend_set: set[str | int],
    ) -> Content:
        # Resolve section content from each source.
        nom_content = self.section_name_to_content[section_key]
        inherited_content = inherited.section_name_to_content[section_key]

        # If content is string-based or null, resolve it directly.
        if nom_content is None and inherited_content is None:
            return None
        if isinstance(nom_content, str) or isinstance(inherited_content, str):
            return self._resolve_content(
                section_key,
                inherited=inherited,
                exclude_set=exclude_set,
                extend_set=extend_set,
                prepend_set=prepend_set,
            )

        # Otherwise, interleave sub-section keys and compile content.
        final_content = {}
        for content in (nom_content, inherited_content):
            if content is None:
                continue
            for key in content:
                if key in final_content:
                    continue
                new_content = self._resolve_content(
                    key,
                    parent=section_key,
                    inherited=inherited,
                    exclude_set=exclude_set,
                    extend_set=extend_set,
                    prepend_set=prepend_set,
                )
                if new_content is None:
                    continue
                final_content[key] = new_content
        return final_content

    # * DATA ATTRIBUTES. ──────────────────────────────────────────────
    @_functools.cached_property
    def annotations(self) -> dict[str, _typing.Any]:
        return self.func.__annotations__.copy()

    @property
    def docstring(self) -> str:
        if "section_name_to_content" not in self.__dict__:
            return _inspect.cleandoc(self.func.__doc__)
        blocks = []
        for section_name, content in self.section_name_to_content.items():
            if content is None:
                continue
            if isinstance(section_name, str):
                blocks.append(section_name)
                blocks.append("-" * len(section_name))
            if isinstance(content, dict):
                for title, string_tup in content.items():
                    blocks.append("".join((title, *string_tup)))
            else:
                blocks.append(content)
            blocks.append("")
        del blocks[-1]
        return "\n".join(blocks)

    @_functools.cached_property
    def section_name_to_content(
        self,
    ) -> _collections.abc.Mapping[str | int, Content]:
        # Make empty mapping to fill.
        section_name_to_content = dict.fromkeys(
            (
                0,  # Short Summary
                1,  # Extended Summary
                "Parameters",
                "Attributes",
                "Returns",
                "Raises",
                "Warnings",
                "See Also",
                "Notes",
                "Examples",
            )
        )

        # Crudely parse docstring and split off summaries.
        parsed = _re.split(r"(?i)([a-z0-9 ]+)\n-{4,}\n", self.docstring)
        summ_lines = parsed.pop(0).splitlines(keepends=True)
        section_name_to_content[0] = summ_lines[0].rstrip()
        # Note: `2` ignores empty line following short summary.
        if len(summ_lines) > 2:
            section_name_to_content[1] = "".join(summ_lines[2:]).rstrip()
        else:
            section_name_to_content[1] = None

        # Slot in each found section.
        for section_name, content in _itertools.batched(
            parsed, 2, strict=True
        ):
            if section_name not in section_name_to_content:
                raise TypeError(
                    f"Section name not recognized: {section_name!r}"
                )
            clean_content = content.rstrip()

            # Identify placeholder content.
            if clean_content == "..." or (
                clean_content[0] == "<" and clean_content[-1] == ">"
            ):
                clean_content = None

            # Parse structured section.
            elif section_name in (
                "Parameters",
                "Attributes",
                "Returns",
                "Raises",
                "See Also",
            ):
                clean_text = clean_content
                clean_content = {}  # *REASSIGNMENT*
                for match in _re.finditer(
                    r"(?ms)(?P<title1>^\S+)(?P<title2>.*?(?:\n|\Z))"
                    r"(?P<resid>.*+(?=\n\S|\Z))?",
                    clean_text,
                ):
                    groups_tup = match.groups()
                    clean_content[groups_tup[0]] = groups_tup[1:]

            # Store final content.
            section_name_to_content[section_name] = clean_content

        # Return mapping.
        return _types.MappingProxyType(section_name_to_content)

    # * PUBLIC METHODS. ───────────────────────────────────────────────
    def wrap(
        self,
        func: _collections.abc.Callable,
        *,
        excludes: _collections.abc.Collection[str | int] = (),
        extends: _collections.abc.Collection[str | int] = (),
        prepends: _collections.abc.Collection[str | int] = (),
    ) -> None:
        # Finalize configuration.
        overrides = (*excludes, *extends, *prepends)
        override_set = set(overrides)
        if len(override_set) < len(overrides):
            raise TypeError(
                "Cannot repeat values between "
                "`excludes`, `extends`, and `prepends`."
            )
        exclude_set = {0, "See Also", "Examples"}
        # Note: `extend_set` is used when a child (such as a parameter)
        # should be extended even though its parent (such as
        # "Parameters") has different default behavior.
        extend_set = set(extends)
        prepend_set = {"Warnings"}
        for targ_set, src_coll in (
            (exclude_set, excludes),
            (prepend_set, prepends),
        ):
            targ_set -= override_set
            targ_set.update(src_coll)
        del excludes, extends, prepends

        # Merge signatures.
        nom_sig = _inspect.signature(self.func)
        name_to_param = dict(nom_sig.parameters)
        inherited_sig = _inspect.signature(func)
        for name, inherited_param in inherited_sig.parameters.items():
            if name in name_to_param or name in exclude_set:
                continue
            new_param = inherited_param.replace(
                kind=_inspect.Parameter.KEYWORD_ONLY
            )
            name_to_param[name] = new_param
        new_sig = nom_sig.replace(parameters=name_to_param.values())
        func.__signature__ = new_sig

        # Merge docstrings.
        inherited = NumpyDoc(func)
        self.section_name_to_content = {
            section_name: self._resolve_section_content(
                section_name,
                inherited=inherited,
                exclude_set=exclude_set,
                extend_set=extend_set,
                prepend_set=prepend_set,
            )
            for section_name in self.section_name_to_content
        }


# endregion

from lgrs.easy import write_grid
from lgrs.coords import BaseCoordinate

nd = NumpyDoc(write_grid)
nd.section_name_to_content
print(nd.docstring)
nd2 = NumpyDoc(BaseCoordinate.distance_to)
nd2.section_name_to_content
print(nd2.docstring)
