"""Support for JavaScript interface."""

# Copyright © 2026, Ethan I. Schaefer (eschaefer@seti.org)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
# implied. See the License for the specific language governing
# permissions and limitations under the License.

###############################################################################
# region> IMPORT
###############################################################################
# Standard.
import builtins as _builtins
import pathlib as _pathlib
import tempfile as _tempfile
import types as _types
import typing as _typing
import shutil as _shutil

# External.
from fiona import collection
import js as _js
import pyodide as _pyodide

# Internal.
import lgrs.easy as _easy


# endregion
###############################################################################
# region> UTILITIES
###############################################################################
def _prep_for_js(
    func: _types.FunctionType, notes: str, *, prepend: bool = False
) -> _types.FunctionType:
    adapter = _easy._Adapter(func)
    adapter.add_to_notes(notes, prepend=prepend)
    new = adapter.make_new_func()
    return new


# endregion
###############################################################################
# region> FUNCTIONS
###############################################################################
# TODO: Delete after testing.
def _minimal_error_example() -> None:
    import fiona

    print(fiona.supported_drivers)
    print("")
    print(fiona.supported_drivers.get("GPKG"))

    import sqlite3

    conn = sqlite3.connect("/tmp/test.sqlite")
    conn.execute("CREATE TABLE foo (id INTEGER)")
    conn.commit()
    conn.close()

    conn = sqlite3.connect("/tmp/test.gpkg")
    conn.execute("CREATE TABLE foo (id INTEGER)")
    conn.commit()
    conn.close()

    import geopandas as gpd
    from shapely.geometry import Point

    gdf = gpd.GeoDataFrame(
        geometry=[Point(0, 0)],
        crs="EPSG:4326",
    )

    gdf.iloc[:0].to_file("/tmp/empty.gpkg", driver="GPKG")
    gdf.to_file("/tmp/min.gpkg", driver="GPKG")


def generate_grid(
    bounds: _typing.Any = None,
    precision: int | str = None,
    out_name: str = "out.gpkg|layer={}",
    **kwargs,
) -> None:
    # Standardize argument values.
    if precision is None:
        raise TypeError("Must specify `precision`.")
    if isinstance(bounds, _pyodide.ffi.JsProxy):
        temp_bounds = bounds.to_py()
        bounds = map(float, temp_bounds[:4])  # *REASSIGNMENT*
        if len(temp_bounds) == 5:
            bounds.append(temp_bounds[4])
    elif bounds is None:
        bounds = []  # *REASSIGNMENT*
        for arg_name in ("left", "bottom", "right", "top"):
            raw_val = kwargs.pop(arg_name, None)
            if raw_val is None:
                raise TypeError(
                    "Neither `bounds` nor its components are specified."
                )
            bounds.append(float(raw_val))
        bounds.append(kwargs.pop("crs", None))
    kwargs["precision"] = precision
    for arg_name, type_hint in _typing.get_type_hints(
        _easy.write_grid
    ).items():
        raw_val = kwargs.get(arg_name)
        if raw_val is None:
            continue
        match type_hint:
            case _builtins.int:
                new_val = int(raw_val)
            case _builtins.float:
                new_val = float(raw_val)
            case _:
                continue
        kwargs[arg_name] = new_val

    # Create temporary directory...
    with _tempfile.TemporaryDirectory(prefix="grid__") as temp_dir_name:

        # Generate grid outputs within temporary directory.
        temp_dir_path = _pathlib.Path(temp_dir_name)
        grid_files_out_dir_path = temp_dir_path / "output_files"
        grid_nom_out_path = grid_files_out_dir_path / out_name
        print(f"Will output to {temp_dir_path}")  # TODO: Delete after testing.
        _easy.write_grid(bounds, out_path=grid_nom_out_path, **kwargs)

        # Zip grid outputs.
        out_zip_path = temp_dir_path / "grid.zip"
        _shutil.make_archive(
            out_zip_path.with_suffix(""), "zip", grid_files_out_dir_path
        )

        # Trigger download.
        data = _pyodide.ffi.to_js(out_zip_path.read_bytes())
        blob = _js.Blob.new([data], {"type": "application/zip"})
        url = _js.URL.createObjectURL(blob)
        a = _js.document.createElement("a")
        a.href = url
        a.download = out_zip_path.name
        a.click()
        _js.URL.revokeObjectURL(url)

        # TODO: Delete temporary code below and uncomment blocks above.
        # for path in temp_dir_path.iterdir():
        #     if path.is_file():
        #         data = _pyodide.ffi.to_js(path.read_bytes())
        #         blob = _js.Blob.new([data])
        #         url = _js.URL.createObjectURL(blob)
        #         a = _js.document.createElement("a")
        #         a.href = url
        #         a.download = path.name
        #         a.click()
        #         _js.URL.revokeObjectURL(url)


def generate_grid_from_form(name: str) -> None:
    form = _js.document.getElementById(name)
    data = _js.FormData(form)
    kwargs = _js.Object.fromEntries(data).to_py()
    # kwargs = {elem.name: elem.value for elem in form.elements if elem.name}
    return generate_grid(**kwargs)
