"""Support for JavaScript interface."""

# Copyright © 2026, Ethan I. Schaefer (eschaefer@seti.org)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
# implied. See the License for the specific language governing
# permissions and limitations under the License.

###############################################################################
# region> IMPORT
###############################################################################
# Standard.
import pathlib as _pathlib
import tempfile as _tempfile
import types as _types
import typing as _typing
import shutil as _shutil

# External.
from fiona import collection
import js as _js
import pyodide as _pyodide

# Internal.
import lgrs.easy as _easy


# endregion
###############################################################################
# region> UTILITIES
###############################################################################
def _prep_for_js(
    func: _types.FunctionType, notes: str, *, prepend: bool = False
) -> _types.FunctionType:
    adapter = _easy._Adapter(func)
    adapter.add_to_notes(notes, prepend=prepend)
    new = adapter.make_new_func()
    return new


# endregion
###############################################################################
# region> FUNCTIONS
###############################################################################
def generate_grid(
    bounds: _typing.Any,
    precision: int,
    out_name: str = "out.gpkg|layer={}",
    **kwargs,
) -> None:
    # Standardize bounds.
    if isinstance(bounds, _pyodide.ffi.JsProxy):
        bounds = bounds.to_py()  # *REASSIGNMENT*

    # Create temporary directory...
    # TODO: Change to `delete=True` (or delete argument, since that's
    #  the default) after testing.
    with _tempfile.TemporaryDirectory(
        prefix="grid__", delete=False
    ) as temp_dir_name:

        # Generate grid outputs within temporary directory.
        out_dir_path = _pathlib.Path(temp_dir_name)
        print(f"Will output to {out_dir_path}")  # TODO: Delete after testing.
        _easy.write_grid(bounds, precision, out_dir_path / out_name, **kwargs)

        # Zip grid outputs.
        # out_zip_path = out_dir_path / "output.zip"
        # _shutil.make_archive(out_zip_path.with_suffix(""), "zip", out_dir_path)

        # Trigger download.
        # data = out_zip_path.read_bytes()
        # blob = _js.Blob.new([data], {"type": "application/zip"})
        # url = _js.URL.createObjectURL(blob)
        # a = _js.document.createElement("a")
        # a.href = url
        # a.download = out_zip_path.name
        # a.click()
        # _js.URL.revokeObjectURL(url)

        # TODO: Delete temporary code below and uncomment blocks above.
        for path in out_dir_path.iterdir():
            if path.is_file():
                data = _pyodide.ffi.to_js(path.read_bytes())
                blob = _js.Blob.new([data])
                url = _js.URL.createObjectURL(blob)
                a = _js.document.createElement("a")
                a.href = url
                a.download = path.name
                a.click()
                _js.URL.revokeObjectURL(url)
