"""Support for JavaScript interface."""

# Copyright © 2026, Ethan I. Schaefer (eschaefer@seti.org)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
# implied. See the License for the specific language governing
# permissions and limitations under the License.

###############################################################################
# region> IMPORT
###############################################################################
# Standard.
import pathlib as _pathlib
import tempfile as _tempfile
import types as _types
import typing as _typing
import shutil as _shutil

# External.
from fiona import collection
import js as _js
import pyodide as _pyodide

# Internal.
import lgrs.easy as _easy


# endregion
###############################################################################
# region> UTILITIES
###############################################################################
def _prep_for_js(
    func: _types.FunctionType, notes: str, *, prepend: bool = False
) -> _types.FunctionType:
    adapter = _easy._Adapter(func)
    adapter.add_to_notes(notes, prepend=prepend)
    new = adapter.make_new_func()
    return new


# endregion
###############################################################################
# region> FUNCTIONS
###############################################################################
# TODO: Delete after testing.
def _minimal_error_example() -> None:
    import fiona

    print(fiona.supported_drivers)
    print("")
    print(fiona.supported_drivers.get("GPKG"))

    import sqlite3

    conn = sqlite3.connect("/tmp/test.sqlite")
    conn.execute("CREATE TABLE foo (id INTEGER)")
    conn.commit()
    conn.close()

    conn = sqlite3.connect("/tmp/test.gpkg")
    conn.execute("CREATE TABLE foo (id INTEGER)")
    conn.commit()
    conn.close()

    import geopandas as gpd
    from shapely.geometry import Point

    gdf = gpd.GeoDataFrame(
        geometry=[Point(0, 0)],
        crs="EPSG:4326",
    )

    gdf.iloc[:0].to_file("/tmp/empty.gpkg", driver="GPKG")
    gdf.to_file("/tmp/min.gpkg", driver="GPKG")


def generate_grid(
    bounds: _typing.Any,
    precision: int,
    out_name: str = "out.gpkg|layer={}",
    **kwargs,
) -> None:
    # Standardize bounds.
    if isinstance(bounds, _pyodide.ffi.JsProxy):
        bounds = bounds.to_py()  # *REASSIGNMENT*

    # Create temporary directory...
    with _tempfile.TemporaryDirectory(prefix="grid__") as temp_dir_name:

        # Generate grid outputs within temporary directory.
        temp_dir_path = _pathlib.Path(temp_dir_name)
        grid_files_out_dir_path = temp_dir_path / "output_files"
        grid_nom_out_path = grid_files_out_dir_path / out_name
        print(f"Will output to {temp_dir_path}")  # TODO: Delete after testing.
        _easy.write_grid(bounds, precision, grid_nom_out_path, **kwargs)

        # Zip grid outputs.
        out_zip_path = temp_dir_path / "grid.zip"
        _shutil.make_archive(
            out_zip_path.with_suffix(""), "zip", grid_files_out_dir_path
        )

        # Trigger download.
        data = _pyodide.ffi.to_js(out_zip_path.read_bytes())
        blob = _js.Blob.new([data], {"type": "application/zip"})
        url = _js.URL.createObjectURL(blob)
        a = _js.document.createElement("a")
        a.href = url
        a.download = out_zip_path.name
        a.click()
        _js.URL.revokeObjectURL(url)

        # TODO: Delete temporary code below and uncomment blocks above.
        # for path in temp_dir_path.iterdir():
        #     if path.is_file():
        #         data = _pyodide.ffi.to_js(path.read_bytes())
        #         blob = _js.Blob.new([data])
        #         url = _js.URL.createObjectURL(blob)
        #         a = _js.document.createElement("a")
        #         a.href = url
        #         a.download = path.name
        #         a.click()
        #         _js.URL.revokeObjectURL(url)
