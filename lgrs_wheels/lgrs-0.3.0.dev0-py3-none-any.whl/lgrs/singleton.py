"""Support for quasi-singletons."""

# Copyright © 2026, Ethan I. Schaefer (eschaefer@seti.org)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
# implied. See the License for the specific language governing
# permissions and limitations under the License.

###############################################################################
# region> IMPORT
###############################################################################
# Standard.
import typing as _typing


# endregion
###############################################################################
# region> CONSTANTS
###############################################################################
def _constant_init(self) -> _typing.NoReturn:
    raise TypeError(f"Cannot instantiate `{type(self)!r}`.")


class ConstantMeta(type):
    """Metaclass for all constants created by `make_constant()`."""

    pass


def make_constant(name: str, *, evaluate_true: bool | None = True) -> type:
    """
    Create a constant with `None`-like behavior.

    The returned constant is a type with a some useful features:
        1) It identifies as an instance of itself, which is useful in type
           hints.
        2) It deters instantiation and subclassing, acting like a quasi-
           singleton.
        3) Copying or deep-copying returns the constant itself.

    Parameters
    ----------
    name : str
        The name of the constant, which becomes part of its string
        representation.
    evaluate_true : bool | None
        Whether constant should evaluate as `True`. If `None` is specified,
        attempting to evaluate `bool(constant)` will raise an exception. The
        default is `True`.

    Returns
    -------
    constant : type
        The new constant.

    Examples
    --------
    >>> CONSTANT = make_constant("CONSTANT")
    >>> isinstance(CONSTANT, CONSTANT)
    True

    You can use the constant like `None` in type hints.

    >>> import collections, typing
    >>> def pop_from_dict(
    ...     d: dict, key: collections.abc.Hashable,
    ...     default: CONSTANT = CONSTANT
    ... ) -> typing.Any:
    ...     if default is CONSTANT:
    ...         return d.pop(key)
    ...     else:
    ...         return d.pop(key, default)

    Each of the following raises an exception, making the constant
    singleton-like.

    >>> CONSTANT()  # doctest: +IGNORE_EXCEPTION_DETAIL
    Traceback (most recent call last):
      ...
    TypeError:
      ...
    >>> CONSTANT.__new__(CONSTANT)  # doctest: +IGNORE_EXCEPTION_DETAIL
    Traceback (most recent call last):
      ...
    TypeError:
      ...
    >>> object.__new__(CONSTANT)  # doctest: +IGNORE_EXCEPTION_DETAIL
    Traceback (most recent call last):
      ...
    TypeError:
      ...
    >>> class Subclass(CONSTANT):  # doctest: +IGNORE_EXCEPTION_DETAIL
    ...     pass
    Traceback (most recent call last):
      ...
    TypeError:
      ...

    Copying or deep-copying returns the constant itself.
    >>> import copy
    >>> copy.copy(CONSTANT) is CONSTANT
    True
    >>> copy.deepcopy(CONSTANT) is CONSTANT
    True
    """
    # Define one-off metaclass, which ensures that the one-off class of
    # its type evaluates as an instance of itself.
    # Note: Also ensure that the one-off class presents as a subclass of
    # `false_base`, to deter use of `object.__new__(cls)` and
    # `cls.__new__(cls)`, without actually evaluating as a subclass of
    # `false_base`.
    false_base = int
    true_base = super
    err_on_bool_chk = evaluate_true is None
    truthiness = bool(evaluate_true)

    class Meta(ConstantMeta):
        __base__ = false_base
        __bases__ = (false_base,) + false_base.__bases__
        __mro__ = __bases__
        __name__ = name

        def __bool__(self) -> bool:
            if err_on_bool_chk:
                raise TypeError(
                    "Boolean evaluation is not supported for "
                    f"the constant: `{self!r}`"
                )
            return truthiness

        def __instancecheck__(self, instance: _typing.Any) -> bool:
            return instance is CONSTANT

        def __new__(self, name, bases, dct, **kwds):
            for base in bases:
                if base is true_base:
                    continue
                if isinstance(base, ConstantMeta):
                    raise TypeError(f"Cannot subclass {CONSTANT!r}.")
            return super().__new__(self, name, bases, dct, **kwds)

        def __repr__(self) -> str:
            return f"<{self.__name__}>"

    # Define one-off class and return it.
    CONSTANT = Meta(
        name,
        (true_base,),
        {
            "__new__": false_base.__new__,
            "__init__": _constant_init,
            "__qualname__": name,
        },
    )
    return CONSTANT


DEFAULT = make_constant("DEFAULT")


# endregion
