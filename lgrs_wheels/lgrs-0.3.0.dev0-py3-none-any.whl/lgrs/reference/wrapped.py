"""
Code to wrap reference scripts.

Examples
--------
>>> import lgrs.coords as coords
>>> latlon_point = coords.LatLonPoint(latitude=85, longitude=1)
>>> lps_point = LatLon2LPS(latlon_point)
>>> latlon_point_recovered = LPS2LatLon(lps_point)
>>> assert latlon_point_recovered.distance_to(latlon_point) < 1e-10

Note that projection is not exact, so distance is not 0 in the above
example. Conversely, interconversion between LGRS and ACC is exact.

>>> lps_lgrs_box = coords.LpsLgrsBox.from_string("AZS1359008480")
>>> lps_acc_box = PolarLGRS2PolarLGRS_ACC(lps_lgrs_box)
>>> lps_lgrs_box_recovered = PolarLGRS_ACC2PolarLGRS(lps_acc_box)
>>> assert lps_lgrs_box == lps_lgrs_box_recovered
"""

# Copyright © 2026, Ethan I. Schaefer (eschaefer@seti.org)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
# implied. See the License for the specific language governing
# permissions and limitations under the License.

###############################################################################
# region> IMPORT
###############################################################################
# Special.
from __future__ import annotations

# Standard.
import contextlib as _contextlib
import io as _io
import sys as _sys

# Internal.
import lgrs.coords as _coords
import lgrs.reference.LGRS_Coordinate_Conversion as _cconv

_cconv.initialize_LGRS_function_globals()


# endregion
###############################################################################
# region> UTILITIES
###############################################################################
_LAST_CMD = None


def _answer_yes(*args, **kwargs) -> str:
    return "y"


def _execute_coordinate_conversion(
    method_name: str,
    value: _coords.BaseCoordinate,
    trunc_val: int,
    return_type: type[_coords.BaseCoordinate],
) -> _coords.BaseCoordinate:
    global _LAST_CMD

    # Execute script, capturing stdout, suppressing prompts, and
    # recording the command.
    args = (method_name, *value._iter_value_strings())
    orig_sys_argv = _sys.argv
    try:
        _sys.argv = ["", *args]
        if isinstance(value, _coords.BoxCoordinate):
            # Note: Command-line execution would apply `condensed=True`,
            # unlike `main()` call further below.
            nom_args = (args[0], "".join(args[1:]))
        else:
            nom_args = args
        _LAST_CMD = f"python {_cconv.__file__} {' '.join(nom_args)}"
        # Note: Prevent prompting and always answer with "y".
        _cconv.main.__globals__["input"] = _answer_yes
        f = _io.StringIO()
        with _contextlib.redirect_stdout(f):
            try:
                _cconv.main(method_name, trunc_val, False)
            except SystemExit:
                raise TypeError(f.getvalue())
    finally:
        _sys.argv = orig_sys_argv
        _cconv.main.__globals__.pop("input", None)
    stdout_str = f.getvalue()

    # Create and return instance.
    if issubclass(return_type, _coords.BoxCoordinate):
        string = stdout_str.strip().replace(" ", "")
        new = return_type.from_string(string)
    else:
        string = stdout_str.strip()
        new = return_type._from_ref_string(string)
    return new


def get_last_command() -> str | None:
    """
    Return most recent command.

    Note that `cmd` may not be identical to the actually executed command
    but should be equivalent. To achieve the same final result, answer "y"
    to any prompt.

    Returns
    -------
    cmd : str or None
        The most recent command. `None` is no command was yet executed.
    """
    return _LAST_CMD


# endregion
###############################################################################
# region> CONVERSION FUNCTIONS
###############################################################################
def LGRS2ACC(
    value: _coords.LtmLgrsBox, *, trunc_val: int = 1
) -> _coords.LtmAccBox:
    return _execute_coordinate_conversion(
        "LGRS2ACC", value, trunc_val, _coords.LtmAccBox
    )


def LGRS2LGRS_ACC(
    value: _coords.LtmLgrsBox, *, trunc_val: int = 1
) -> _coords.LtmAccBox:
    return _execute_coordinate_conversion(
        "LGRS2LGRS_ACC", value, trunc_val, _coords.LtmAccBox
    )


def LGRS2LTM(
    value: _coords.LtmLgrsBox, *, trunc_val: int = 0
) -> _coords.LtmPoint:
    return _execute_coordinate_conversion(
        "LGRS2LTM", value, trunc_val, _coords.LtmPoint
    )


def LGRS2LatLon(
    value: _coords.LtmLgrsBox, *, trunc_val: int = 0
) -> _coords.LatLonPoint:
    return _execute_coordinate_conversion(
        "LGRS2LatLon", value, trunc_val, _coords.LatLonPoint
    )


def LGRS_ACC2LGRS(
    value: _coords.LtmAccBox, *, trunc_val: int = 1
) -> _coords.LtmLgrsBox:
    return _execute_coordinate_conversion(
        "LGRS_ACC2LGRS", value, trunc_val, _coords.LtmLgrsBox
    )


def LGRS_ACC2LTM(
    value: _coords.LtmAccBox, *, trunc_val: int = 0
) -> _coords.LtmPoint:
    return _execute_coordinate_conversion(
        "LGRS_ACC2LTM", value, trunc_val, _coords.LtmPoint
    )


def LGRS_ACC2LatLon(
    value: _coords.LtmAccBox, *, trunc_val: int = 0
) -> _coords.LatLonPoint:
    return _execute_coordinate_conversion(
        "LGRS_ACC2LatLon", value, trunc_val, _coords.LatLonPoint
    )


def LPS2ACC(
    value: _coords.LpsPoint, *, trunc_val: int = 1
) -> _coords.LtmAccBox:
    return _execute_coordinate_conversion(
        "LPS2ACC", value, trunc_val, _coords.LtmAccBox
    )


def LPS2LatLon(
    value: _coords.LpsPoint, *, trunc_val: int = 0
) -> _coords.LatLonPoint:
    return _execute_coordinate_conversion(
        "LPS2LatLon", value, trunc_val, _coords.LatLonPoint
    )


def LPS2PolarLGRS(
    value: _coords.LpsPoint, *, trunc_val: int = 1
) -> _coords.LpsLgrsBox:
    return _execute_coordinate_conversion(
        "LPS2PolarLGRS", value, trunc_val, _coords.LpsLgrsBox
    )


def LPS2PolarLGRS_ACC(
    value: _coords.LpsPoint, *, trunc_val: int = 1
) -> _coords.LpsAccBox:
    return _execute_coordinate_conversion(
        "LPS2PolarLGRS_ACC", value, trunc_val, _coords.LpsAccBox
    )


def LTM2ACC(
    value: _coords.LtmPoint, *, trunc_val: int = 1
) -> _coords.LtmAccBox:
    return _execute_coordinate_conversion(
        "LTM2ACC", value, trunc_val, _coords.LtmAccBox
    )


def LTM2LGRS(
    value: _coords.LtmPoint, *, trunc_val: int = 1
) -> _coords.LtmLgrsBox:
    return _execute_coordinate_conversion(
        "LTM2LGRS", value, trunc_val, _coords.LtmLgrsBox
    )


def LTM2LGRS_ACC(
    value: _coords.LtmPoint, *, trunc_val: int = 1
) -> _coords.LtmAccBox:
    return _execute_coordinate_conversion(
        "LTM2LGRS_ACC", value, trunc_val, _coords.LtmAccBox
    )


def LTM2LatLon(
    value: _coords.LtmPoint, *, trunc_val: int = 0
) -> _coords.LatLonPoint:
    return _execute_coordinate_conversion(
        "LTM2LatLon", value, trunc_val, _coords.LatLonPoint
    )


def LatLon2ACC(
    value: _coords.LatLonPoint, *, trunc_val: int = 1
) -> _coords.LtmAccBox:
    return _execute_coordinate_conversion(
        "LatLon2ACC", value, trunc_val, _coords.LtmAccBox
    )


def LatLon2LGRS(
    value: _coords.LatLonPoint, *, trunc_val: int = 1
) -> _coords.LtmLgrsBox:
    return _execute_coordinate_conversion(
        "LatLon2LGRS", value, trunc_val, _coords.LtmLgrsBox
    )


def LatLon2LGRS_ACC(
    value: _coords.LatLonPoint, *, trunc_val: int = 1
) -> _coords.LtmAccBox:
    return _execute_coordinate_conversion(
        "LatLon2LGRS_ACC", value, trunc_val, _coords.LtmAccBox
    )


def LatLon2LPS(
    value: _coords.LatLonPoint, *, trunc_val: int = 0
) -> _coords.LpsPoint:
    return _execute_coordinate_conversion(
        "LatLon2LPS", value, trunc_val, _coords.LpsPoint
    )


def LatLon2LTM(
    value: _coords.LatLonPoint, *, trunc_val: int = 0
) -> _coords.LtmPoint:
    return _execute_coordinate_conversion(
        "LatLon2LTM", value, trunc_val, _coords.LtmPoint
    )


def LatLon2PolarLGRS(
    value: _coords.LatLonPoint, *, trunc_val: int = 1
) -> _coords.LpsLgrsBox:
    return _execute_coordinate_conversion(
        "LatLon2PolarLGRS", value, trunc_val, _coords.LpsLgrsBox
    )


def LatLon2PolarLGRS_ACC(
    value: _coords.LatLonPoint, *, trunc_val: int = 1
) -> _coords.LpsAccBox:
    return _execute_coordinate_conversion(
        "LatLon2PolarLGRS_ACC", value, trunc_val, _coords.LpsAccBox
    )


def LatLon2Polar_ACC(
    value: _coords.LatLonPoint, *, trunc_val: int = 1
) -> _coords.LpsAccBox:
    return _execute_coordinate_conversion(
        "LatLon2Polar_ACC", value, trunc_val, _coords.LpsAccBox
    )


def PolarLGRS2LPS(
    value: _coords.LpsLgrsBox, *, trunc_val: int = 0
) -> _coords.LpsPoint:
    return _execute_coordinate_conversion(
        "PolarLGRS2LPS", value, trunc_val, _coords.LpsPoint
    )


def PolarLGRS2LatLon(
    value: _coords.LpsLgrsBox, *, trunc_val: int = 0
) -> _coords.LatLonPoint:
    return _execute_coordinate_conversion(
        "PolarLGRS2LatLon", value, trunc_val, _coords.LatLonPoint
    )


def PolarLGRS2PolarLGRS_ACC(
    value: _coords.LpsLgrsBox, *, trunc_val: int = 1
) -> _coords.LpsAccBox:
    return _execute_coordinate_conversion(
        "PolarLGRS2PolarLGRS_ACC", value, trunc_val, _coords.LpsAccBox
    )


def PolarLGRS2Polar_ACC(
    value: _coords.LpsLgrsBox, *, trunc_val: int = 1
) -> _coords.LpsAccBox:
    return _execute_coordinate_conversion(
        "PolarLGRS2Polar_ACC", value, trunc_val, _coords.LpsAccBox
    )


def PolarLGRS_ACC2LPS(
    value: _coords.LpsAccBox, *, trunc_val: int = 0
) -> _coords.LpsPoint:
    return _execute_coordinate_conversion(
        "PolarLGRS_ACC2LPS", value, trunc_val, _coords.LpsPoint
    )


def PolarLGRS_ACC2LatLon(
    value: _coords.LpsAccBox, *, trunc_val: int = 0
) -> _coords.LatLonPoint:
    return _execute_coordinate_conversion(
        "PolarLGRS_ACC2LatLon", value, trunc_val, _coords.LatLonPoint
    )


def PolarLGRS_ACC2PolarLGRS(
    value: _coords.LpsAccBox, *, trunc_val: int = 1
) -> _coords.LpsLgrsBox:
    return _execute_coordinate_conversion(
        "PolarLGRS_ACC2PolarLGRS", value, trunc_val, _coords.LpsLgrsBox
    )


# endregion
